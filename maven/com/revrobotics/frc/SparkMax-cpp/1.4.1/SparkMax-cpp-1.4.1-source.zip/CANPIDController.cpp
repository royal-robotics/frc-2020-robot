/*
 * Copyright (c) 2018-2019 REV Robotics
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of REV Robotics nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include "rev/CANPIDController.h"

#include "rev/CANSparkMax.h"
#include "rev/CANSparkMaxDriver.h"
#include "rev/CANSparkMaxErrors.h"

using namespace rev;

CANPIDController::CANPIDController(CANSparkMax& device) : m_device(&device) {}

CANError CANPIDController::SetReference(double value, ControlType ctrl,
                                        int pidSlot, double arbFF, ArbFFUnits arbFFUnits) {
  
    auto status = c_SparkMax_SetpointCommand(static_cast<c_SparkMax_handle>(m_device->m_sparkMax),
                                            value,
                                            static_cast<c_SparkMax_ControlType>(ctrl),
                                            pidSlot,
                                            arbFF,
                                            static_cast<int>(arbFFUnits));
    return static_cast<CANError>(status);
}

CANError CANPIDController::SetP(double gain, int slotID) {
    auto status = c_SparkMax_SetP(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), slotID, gain);
    return static_cast<CANError>(status);
}

CANError CANPIDController::SetI(double gain, int slotID) {
    auto status = c_SparkMax_SetI(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), slotID, gain);
    return static_cast<CANError>(status);
}

CANError CANPIDController::SetD(double gain, int slotID) {
    auto status = c_SparkMax_SetD(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), slotID, gain);
    return static_cast<CANError>(status);
}

CANError CANPIDController::SetDFilter(double gain, int slotID) {
    auto status = c_SparkMax_SetDFilter(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), slotID, gain);
    return static_cast<CANError>(status);
}

CANError CANPIDController::SetFF(double gain, int slotID) {
    auto status = c_SparkMax_SetFF(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), slotID, gain);
    return static_cast<CANError>(status);
}

CANError CANPIDController::SetIZone(double IZone, int slotID) {
    auto status = c_SparkMax_SetIZone(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), slotID, IZone);
    return static_cast<CANError>(status);
}

CANError CANPIDController::SetOutputRange(double min, double max, int slotID) {
    auto status = c_SparkMax_SetOutputRange(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), slotID, min, max);
    return static_cast<CANError>(status);
}

double CANPIDController::GetP(int slotID) {
    float tmp;
    c_SparkMax_GetP(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), slotID, &tmp);
    return static_cast<double>(tmp);
}

double CANPIDController::GetI(int slotID) {
    float tmp;
    c_SparkMax_GetI(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), slotID, &tmp);
    return static_cast<double>(tmp);
}

double CANPIDController::GetD(int slotID) {
    float tmp;
    c_SparkMax_GetD(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), slotID, &tmp);
    return static_cast<double>(tmp);
}

double CANPIDController::GetDFilter(int slotID) {
    float tmp;
    c_SparkMax_GetDFilter(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), slotID, &tmp);
    return static_cast<double>(tmp);
}

double CANPIDController::GetFF(int slotID) {
    float tmp;
    c_SparkMax_GetFF(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), slotID, &tmp);
    return static_cast<double>(tmp);
}

double CANPIDController::GetIZone(int slotID) {
    float tmp;
    c_SparkMax_GetIZone(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), slotID, &tmp);
    return static_cast<double>(tmp);
}

double CANPIDController::GetOutputMin(int slotID) {
    float tmp;
    c_SparkMax_GetOutputMin(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), slotID, &tmp);
    return static_cast<double>(tmp);
}

double CANPIDController::GetOutputMax(int slotID) {
    float tmp;
    c_SparkMax_GetOutputMax(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), slotID, &tmp);
    return static_cast<double>(tmp);
}

CANError CANPIDController::SetSmartMotionMaxVelocity(double maxVel,
                                                     int slotID) {
    auto status = c_SparkMax_SetSmartMotionMaxVelocity(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), slotID, maxVel);
    return static_cast<CANError>(status);
}

CANError CANPIDController::SetSmartMotionMaxAccel(double maxAccel, int slotID) {
    auto status = c_SparkMax_SetSmartMotionMaxAccel(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), slotID, maxAccel);
    return static_cast<CANError>(status);
}

CANError CANPIDController::SetSmartMotionMinOutputVelocity(double minVel,
                                                           int slotID) {
    auto status = c_SparkMax_SetSmartMotionMinOutputVelocity(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), slotID, minVel);
    return static_cast<CANError>(status);
}

CANError CANPIDController::SetSmartMotionAllowedClosedLoopError(
    double allowedErr, int slotID) {
    auto status = c_SparkMax_SetSmartMotionAllowedClosedLoopError(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), slotID, allowedErr);
    return static_cast<CANError>(status);
}

CANError CANPIDController::SetSmartMotionAccelStrategy(
    CANPIDController::AccelStrategy accelStrategy, int slotID) {
    auto status = c_SparkMax_SetSmartMotionAllowedClosedLoopError(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), slotID, static_cast<c_SparkMax_AccelStrategy>(accelStrategy));
    return static_cast<CANError>(status);
}

double CANPIDController::GetSmartMotionMaxVelocity(int slotID) {
    float tmp;
    c_SparkMax_GetSmartMotionMaxVelocity(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), slotID, &tmp);
    return static_cast<double>(tmp);
}

double CANPIDController::GetSmartMotionMaxAccel(int slotID) {
    float tmp;
    c_SparkMax_GetSmartMotionMaxAccel(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), slotID, &tmp);
    return static_cast<double>(tmp);
}

double CANPIDController::GetSmartMotionMinOutputVelocity(int slotID) {
    float tmp;
    c_SparkMax_GetSmartMotionMinOutputVelocity(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), slotID, &tmp);
    return static_cast<double>(tmp);
}

double CANPIDController::GetSmartMotionAllowedClosedLoopError(int slotID) {
    float tmp;
    c_SparkMax_GetSmartMotionAllowedClosedLoopError(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), slotID, &tmp);
    return static_cast<double>(tmp);
}

CANPIDController::AccelStrategy CANPIDController::GetSmartMotionAccelStrategy(int slotID) {
    c_SparkMax_AccelStrategy tmp;
    c_SparkMax_GetSmartMotionAccelStrategy(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), slotID, &tmp);
    return static_cast<CANPIDController::AccelStrategy>(tmp);
}

CANError CANPIDController::SetIMaxAccum(double iMaxAccum, int slotID) {
    auto status = c_SparkMax_SetIMaxAccum(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), slotID, iMaxAccum);
    return static_cast<CANError>(status);
}

double CANPIDController::GetIMaxAccum(int slotID) {
    float tmp;
    c_SparkMax_GetIMaxAccum(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), slotID, &tmp);
    return static_cast<double>(tmp);
}

CANError CANPIDController::SetIAccum(double iAccum) {
    auto status = c_SparkMax_SetIAccum(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), iAccum);
    return static_cast<CANError>(status);
}

double CANPIDController::GetIAccum() {
    float tmp;
    c_SparkMax_GetIAccum(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), &tmp);
    return static_cast<double>(tmp);
}

CANError CANPIDController::SetFeedbackDevice(const CANSensor& sensor) {
    auto status = c_SparkMax_SetFeedbackDevice(static_cast<c_SparkMax_handle>(m_device->m_sparkMax), 
        static_cast<uint32_t>(sensor.GetID()));
    return static_cast<CANError>(status);
}
